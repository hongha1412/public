const puppeteer = require('puppeteer');
const axios = require('axios');
const fs = require('fs');
const path = require('path');

// Path to save cookies
const DATA_PATH = path.join(__dirname, 'msb_sessiondata.json');
const BRANCHES_PATH = path.join(__dirname, 'msb.txt');

// Prepare data store
const data = { branches: [] };

(async () => {
    // Request to get branches and atms
    try {
        const branches = await axios.get(`https://www.msb.com.vn/o/headless-branch/v1.0/branch?pageSize=1000&page=1`);
        data.branches.push(...branches.data.items.map(i => {
            i.type = 'branch';
            return i;
        }));
        const atms = await axios.get(`https://www.msb.com.vn/o/headless-atm/v1.0/atm?pageSize=1000&page=1`);
        data.branches.push(...atms.data.items.map(i => {
            i.type = 'atm';
            return i;
        }));
    } catch (error) {
        console.error('Error making API request provincesresult:', error);
    }
    
    writeToFile(BRANCHES_PATH, data);
})();

var writeToFile = (path, data) => {
    // Write the data to the file
    fs.writeFile(path, JSON.stringify(data), (err) => {
        if (err) {
            return console.error('Error writing file:', err);
        }
        console.log('Data saved successfully!');
    });
};

var sleep = async (time) => {
    console.log(`Going to sleep ${time}ms`);
    return new Promise((resolve) => {
        setTimeout(() => resolve(), time);
    });
};

var randomTime = (min, max) => {
    return Math.floor(Math.random() * (max - min + 1)) + min;
};
