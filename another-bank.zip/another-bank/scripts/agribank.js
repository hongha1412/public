const puppeteer = require('puppeteer');
const axios = require('axios');
const fs = require('fs');
const path = require('path');

// Path to save cookies
const DATA_PATH = path.join(__dirname, 'agribank_sessiondata.json');
const BRANCHES_PATH = path.join(__dirname, 'agribank.txt');

(async () => {
    // Launch Puppeteer
    const browser = await puppeteer.launch({headless: false});
    const page = await browser.newPage();
    
    // Navigate to the first URL
    await page.goto('https://www.agribank.com.vn/vn/atm-chi-nhanh');

    // Wait until the page is fully loaded
    await page.waitForSelector('.search_atm_ct');
    await page.waitForSelector('#cityBranch');
    
    // Extract provinces
    const provinces = await page.evaluate(() => {
      const options = Array.from(document.querySelectorAll('#cityBranch > option'));
      return options.filter(option => option.value && option.value !== 'Tỉnh/Thành phố').map(o => {return { name: o.textContent, value: o.value }});
    });
    
    // Extract branches
    const data = { branches: [] };
    for (let i = 0; i < provinces.length; i++) {
        const province = provinces[i];
        // Select province
        await page.select('#cityBranch', province.value);
        
        // Wait for branches update
        await sleep(2000);
        await page.waitForSelector('.search_atm_ct');
        
        const branches = await page.evaluate(() => {
            return Array.from(document.querySelectorAll('.search_atm_ct > div')).map(e => {
                const rs = {};
                const parts = e.innerText.split('\n');
                let value = parts.shift();
                while (!value) value = parts.shift();
                rs.name = value;
                value = parts.shift();
                while (!value) value = parts.shift();
                rs.address = value;
                return rs;
            })
        });
        data.branches.push(...branches);
    }

    // Close the browser as it's no longer needed
    await browser.close();
    
    writeToFile(BRANCHES_PATH, data);
})();

var writeToFile = (path, data) => {
    // Write the data to the file
    fs.writeFile(path, JSON.stringify(data), (err) => {
        if (err) {
            return console.error('Error writing file:', err);
        }
        console.log('Data saved successfully!');
    });
};

var sleep = async (time) => {
    console.log(`Going to sleep ${time}ms`);
    return new Promise((resolve) => {
        setTimeout(() => resolve(), time);
    });
};

var randomTime = (min, max) => {
    return Math.floor(Math.random() * (max - min + 1)) + min;
};
