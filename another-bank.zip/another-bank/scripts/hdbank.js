const CryptoJS = require('crypto-js');
const puppeteer = require('puppeteer');
const axios = require('axios');
const fs = require('fs');
const path = require('path');

// Path to save cookies
const DATA_PATH = path.join(__dirname, 'hdbank_sessiondata.json');
const BRANCHES_PATH = path.join(__dirname, 'hdbank.txt');

// Prepare data store
const data = {branches: []};

(async () => {
    try {
        const branches = await axios.get(`https://hdbank.com.vn/api/network/branch`);
        data.branches.push(...decryptText(branches.data));
        writeToFile(BRANCHES_PATH, data);
    } catch (error) {
        console.error('Error making API request provincesresult:', error);
    }
})();

var decryptText = (encryptedBase64) => {
    // AES key
    // const key = 'e5ch*sfsAl8rX@H#'; // This key is 16 bytes, suitable for AES-128
    const key = 'Z9GRKIgYKH2CUdqfas858Q==';

    // Initialization vector (IV) - 16 bytes for AES
    const iv = CryptoJS.enc.Utf8.parse(key); // IV of 16 bytes filled with zeros

    // Decrypt the Base64 string using AES
    function decryptAES(encText) {
        const decrypted = CryptoJS.AES.decrypt(
            encText, iv, {
                mode: CryptoJS.mode.ECB,
                padding: CryptoJS.pad.Pkcs7
            }
        );

        return JSON.parse(CryptoJS.enc.Utf8.stringify(decrypted));
    }

    // Perform the decryption
    return decryptAES(encryptedBase64);
}

var writeToFile = (path, data) => {
    // Write the data to the file
    fs.writeFile(path, JSON.stringify(data), (err) => {
        if (err) {
            return console.error('Error writing file:', err);
        }
        console.log('Data saved successfully!');
    });
};

var sleep = async (time) => {
    console.log(`Going to sleep ${time}ms`);
    return new Promise((resolve) => {
        setTimeout(() => resolve(), time);
    });
};

var randomTime = (min, max) => {
    return Math.floor(Math.random() * (max - min + 1)) + min;
};
