const puppeteer = require('puppeteer');
const axios = require('axios');
const fs = require('fs');
const path = require('path');

// Path to save cookies
const DATA_PATH = path.join(__dirname, 'sacombank_sessiondata.json');
const BRANCHES_PATH = path.join(__dirname, 'sacombank.txt');

// Prepare data store
const data = { branches: [], branchType: [] };

(async () => {
    // Request to get branches and atms
    try {
        let branches = await axios.get(`https://www.sacombank.com.vn/trang-chu/danh-sach-atm-dgd/_jcr_content/root/container/container/promotiondealerlocat.sacom.dealerlocatorlist.json`);
        branches = branches.data.data.pop();
        data.branchType.push(...branches.locationType);
        data.branches.push(...branches.location);
    } catch (error) {
        console.error('Error making API request provincesresult:', error);
    }
    
    writeToFile(BRANCHES_PATH, data);
})();

var writeToFile = (path, data) => {
    // Write the data to the file
    fs.writeFile(path, JSON.stringify(data), (err) => {
        if (err) {
            return console.error('Error writing file:', err);
        }
        console.log('Data saved successfully!');
    });
};

var sleep = async (time) => {
    console.log(`Going to sleep ${time}ms`);
    return new Promise((resolve) => {
        setTimeout(() => resolve(), time);
    });
};

var randomTime = (min, max) => {
    return Math.floor(Math.random() * (max - min + 1)) + min;
};
