const fs = require('fs');
const path = require('path');

const BASE_PATH = path.join(__dirname, '..', 'output');
const PROVINCE_MAPPING_PATH = path.join(__dirname, 'province_mapping.json');

const provinceMapping = JSON.parse(fs.readFileSync(PROVINCE_MAPPING_PATH, 'utf8'));
const atmDetect = ['atm', 'crm', 'cdm'];

function customData(bank, data, master = undefined) {
    // Adjust data
    if (bank.startsWith('bidv')) {
        data.province = data.Province;
        // data.type = (data.BranchType || '').toLowerCase();
        data.type = atmDetect.some(s => data.BranchType.toLowerCase().includes(s)) ? 'ATM/CRM/CDM' : 'branch';
        return;
    } else if (bank.startsWith('tpbank')) {
        if (!data.type || data.type === '2.0') {
            data.title += ' (CRM/CDM)';
            data.type = 'ATM/CRM/CDM';
        } else {
            data.type = 'branch';
        }
        data.lat = data.position?.latitude;
        data.lng = data.position?.longitude;
    } else if (bank.startsWith('vpbank')) {
        data.type = data.IsBranch ? 'branch' : 'ATM/CRM/CDM';
    } else if (bank.startsWith('acb') && data.city) {
        data.province = data.city;
        data.type = data.is_branch ? 'branch' : 'ATM/CRM/CDM';
    } else if (bank.startsWith('hdbank')) {
        data.lat = data.location?.lat;
        data.lng = data.location?.lng;
        data.type = 'branch';
    } else if (bank.startsWith('agribank') || bank.startsWith('shb')) {
        data.type = atmDetect.some(s => data.name.toLowerCase().includes(s)) ? 'ATM/CRM/CDM' : 'branch';
    } else if (bank.startsWith('mb') || bank.startsWith('vcb') || bank.startsWith('sacombank')) {
        data.type = 'branch';
    } else if (bank.startsWith('vietin')) {
        data.type = atmDetect.some(s => data.type.toLowerCase().includes(s)) ? 'ATM/CRM/CDM' : 'branch';
    }
    // Skip existing province
    if (data.province && typeof data.province === 'string') return;

    // Get province from address
    if (bank.startsWith('agribank')) data.address = data.address.replace(/địa chỉ:/ig, '').trim();
    else if (bank.startsWith('tpbank')) data.address = data.content;
    const address = (data.address || data.Address || data.Addr || '').split(/[,-]/);
    while (address[address.length - 1].toLowerCase().trim().indexOf('việt nam') >= 0) address.pop();
    data.province = address.pop().trim().replace(/thành phố/ig, '').replace(/tỉnh/ig, '').replace(/tp?\.|tp/ig, '').trim();
    if (data.province.endsWith('.')) data.province = data.province.substring(0, data.province.length - 1);
}

function customFilter(bank, data) {
    // if (bank.startsWith('agribank')) {
    //     return !data.name?.trim().toUpperCase().startsWith('ATM');
    // } else if (bank.startsWith('bidv')) {
    //     return data.type !== 'atm';
    // } else if (bank.startsWith('msb') || bank.startsWith('vpbank') || bank.startsWith('acb')) {
    //     return data.type === 'branch';
    // } else if (bank.startsWith('sacombank')) {
    //     return !data.type.includes('atm');
    // } else if (bank.startsWith('vietin')) {
    //     return data.type !== 'ATM';
    // } else if (bank.startsWith('vib')) {
    //     return data.type.toLowerCase() !== 'atm';
    // }
    return data.type.toLowerCase() === 'branch';
}

function normalizeBranch(bank, data) {
    if ('branches' in data) {
        // Custom process for vcb
        if (bank.startsWith('vcb')) {
            const tmp = [];
            data.branches.forEach((group) => {
                tmp.push(...group.branches);
            });
            data.branches = tmp;
        }
        // Example for formats 1, 2, 4, 5, 6, 8
        const process = (branches, master = undefined) => {
            branches.forEach((branch) => customData(bank, branch, master));
            return branches.map((branch) => {
                return {
                    name: (branch.name || branch.Name || branch.branch_name || branch.title || branch.NameEn || branch.nameEn || (bank.startsWith('vietin') ? (branch.type || '') : '')).replace(/\r?\n/g, ' '),
                    address: (branch.address || branch.Addr || branch.Address || branch.content || '').replace(/\r?\n/g, ' '),
                    latitude: parseFloat(branch.latitude || branch.Lat || branch.lat || branch.latitude || branch.Latitude) || '',
                    longitude: parseFloat(branch.longitude || branch.Lon || branch.lon || branch.lng || branch.longtitude || branch.Longitude) || '',
                    phone: (branch.phone || branch.Phone || branch.phoneNumber || branch.corporatePhone || '').replace(/\r?\n/g, ' '),
                    workingTime: (branch.workingTime || branch.WorkingTime || branch.services_hour || branch.operatingHours || '').replace(/\r?\n/g, ' '),
                    province: (branch.province || '').replace(/\r?\n/g, ' '),
                    type: branch.type || branch.categoryCode || ''
                }
            }).filter((branch) => customFilter(bank, branch)).map((branch) => branch);
        };
        if (Array.isArray(data.branches)) {
            // Handle formats where branches is an array
            return process(data.branches);
        } else if (data.branches && typeof data.branches === 'object') {
            // Handle format 3
            const allBranches = data.branches.lstBrank;
            return process(allBranches);
        } else {
            console.error("Unexpected data format");
            return null;
        }
    } else if ('branches' in data && 'lstAtm' in data.branches) {
        // Example for format 3
        data.branches.lstBrank.forEach((branch) => customData(bank, branch, master));
        return data.branches.lstBrank.map((branch) => ({
            name: branch.name.replace(/\r?\n/g, ' '),
            address: branch.address,
            latitude: parseFloat(branch.latitude) || '',
            longitude: parseFloat(branch.longitude) || '',
            phone: branch.phone,
            workingTime: branch.description?.replace(/&lt;[^>]*>/g, ''), // remove HTML tags
            province: branch.province || '',
            type: branch.type || ''
        })).filter((branch) => customFilter(bank, branch)).map((branch) => branch);
    } else if ('provinces' in data && 'networkProvince' in data.provinces) {
        // Example for format 7
        data.branches.forEach((branch) => customData(bank, branch, master));
        return data.branches.map((branch) => ({
            name: branch.type,
            address: branch.address,
            latitude: '', longitude: '', phone: '', workingTime: '',
            province: branch.province || '', type: branch.type || ''
        })).filter((branch) => customFilter(bank, branch)).map((branch) => branch);
    } else {
        console.log('Format not supported');
        // Handle any unexpected formats or return an empty array
        return [];
    }
}

var writeToFile = (path, data) => {
    // Write the data to the file
    fs.writeFile(path, JSON.stringify(data), (err) => {
        if (err) {
            return console.error('Error writing file:', err);
        }
        console.log('Data saved successfully!');
    });
};

var writeToCsvFile = (path, data) => {
    if (!Array.isArray(data) || data.length <= 0) return;

    const csv = [];
    const keys = Object.keys(data[0]);
    // Prepare csv header
    csv.push(keys.filter(k => k !== 'type').join('\t'));
    // Push csv rows
    csv.push(...data.map(d => Object.values(d).filter((_, i) => keys[i] !== 'type').join('\t')));

    // Write the data to the file
    fs.writeFile(path, csv.join('\n'), (err) => {
        if (err) {
            return console.error('Error writing csv file:', err);
        }
        console.log('Csv data saved successfully!');
    });
};

var postprocess = (data) => {
    const removeVietnameseTones = (str) => {
        return str
            .normalize('NFD') // Tách các ký tự tổ hợp (dấu) ra khỏi ký tự chính
            .replace(/[\u0300-\u036f]/g, '') // Loại bỏ các dấu
            .replace(/đ/g, 'd') // Thay ký tự 'đ' thường thành 'd'
            .replace(/Đ/g, 'D') // Thay ký tự 'Đ' hoa thành 'D'
            .replace(/[^a-zA-Z0-9\s]/g, '') // Loại bỏ các ký tự đặc biệt
            .trim(); // Xóa khoảng trắng ở đầu và cuối chuỗi
    };
    const normalizeSpaces = (input) => {
        return input.replace(/\s+/g, ' ').trim();
    };
    const calculateMatchPercentage = (address, query) => {
        // Chuyển cả hai chuỗi về chữ thường để so sánh không phân biệt hoa/thường
        const normalizedAddress = address.toLowerCase();
        const normalizedQuery = query.toLowerCase();
    
        // Tách các từ trong địa chỉ và chuỗi tìm kiếm
        const addressWords = normalizedAddress.split(/\s+/);
        const queryWords = normalizedQuery.split(/\s+/);
    
        // Đếm số từ trong query xuất hiện trong address
        let matchCount = 0;
    
        queryWords.forEach((queryWord) => {
            addressWords.forEach((addressWord) => {
                // Đo độ tương đồng của từng từ sử dụng Levenshtein Distance
                const similarity = calculateStringSimilarity(addressWord, queryWord);
                if (similarity > 0.8) { // Nếu tương đồng > 80%, coi như có mặt
                    matchCount++;
                    return; // Dừng kiểm tra từ này
                }
            });
        });
    
        // Tính tỷ lệ xuất hiện
        return ((matchCount / queryWords.length) * 100).toFixed(2); // Trả về % khớp
    };
    
    // Hàm tính độ tương đồng giữa 2 chuỗi (Levenshtein Distance)
    const calculateStringSimilarity = (str1, str2) => {
        const len1 = str1.length;
        const len2 = str2.length;
    
        if (len1 === 0) return len2 === 0 ? 1 : 0;
        if (len2 === 0) return 0;
    
        const dp = Array.from({ length: len1 + 1 }, () => Array(len2 + 1).fill(0));
        for (let i = 0; i <= len1; i++) dp[i][0] = i;
        for (let j = 0; j <= len2; j++) dp[0][j] = j;
    
        for (let i = 1; i <= len1; i++) {
            for (let j = 1; j <= len2; j++) {
                const cost = str1[i - 1] === str2[j - 1] ? 0 : 1;
                dp[i][j] = Math.min(
                    dp[i - 1][j] + 1,    // Xóa
                    dp[i][j - 1] + 1,    // Thêm
                    dp[i - 1][j - 1] + cost // Thay thế
                );
            }
        }
    
        const levenshteinDistance = dp[len1][len2];
        const maxLength = Math.max(len1, len2);
        return (maxLength - levenshteinDistance) / maxLength;
    }

    const tryProvinces = provinceMapping.map(p => p.name);
    let point1;
    let point2;
    data.forEach(d => {
        if (d.address) {
            for (let name of tryProvinces) {
                for (let tp of provinceMapping.filter(p => p.name === name)[0].string) {
                    point1 = calculateMatchPercentage(normalizeSpaces(removeVietnameseTones(d.address.toLowerCase())), removeVietnameseTones(tp));
                    point2 = calculateMatchPercentage(normalizeSpaces(removeVietnameseTones(d.province.toLowerCase())), removeVietnameseTones(tp));
                    if (point1 >= 66 || point2 >= 66) {
                        d.province = name;
                        return;
                    }
                }
            }
        }
    });
}

const banks = fs.readdirSync(__dirname).filter(p => path.extname(p) === '.txt');
const all = [];
if (fs.existsSync(BASE_PATH))
    fs.rmSync(BASE_PATH, { recursive: true, force: true });
fs.mkdirSync(BASE_PATH, {recursive: true});

for (let i = 0; i < banks.length; i++) {
    console.log('Reading data from', banks[i]);
    const jsonData = JSON.parse(fs.readFileSync(path.join(__dirname, banks[i]), 'utf8'));
    const normalizeData = normalizeBranch(banks[i], jsonData);
    postprocess(normalizeData);
    all.push(...normalizeData);
    writeToCsvFile(path.join(BASE_PATH, banks[i].replace(path.extname(banks[i]), '.csv')), normalizeData);
}

writeToFile(path.join(BASE_PATH, 'all.json'), all);
