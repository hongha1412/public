const puppeteer = require('puppeteer');
const axios = require('axios');
const fs = require('fs');
const path = require('path');

// Path to save cookies
const DATA_PATH = path.join(__dirname, 'vib_sessiondata.json');
const BRANCHES_PATH = path.join(__dirname, 'vib.txt');

// Prepare data store
const data = { branches: [] };

(async () => {
    // Build form urlencoded post data
    const postObject = {
        inputSearch: '*',
        atm: 'ATM',
        branch: 'BRANCH'
    };
    const postData = Object.keys(postObject)
        .map((key) => `${key}=${encodeURIComponent(postObject[key])}`)
        .join('&');

    // Make api request to get branches in province
    const branches = await axios.post(`https://www.vib.com.vn/VIBAtmBranch/content/jsp/process/search.jsp`,
        postData,
        {
            headers: {
                'content-type': 'application/x-www-form-urlencoded; charset=UTF-8'
            }
        }
    );
    // Store into data
    data.branches.push(...branches.data);
    // Flush current data to file
    writeToFile(BRANCHES_PATH, data);
})();

var writeToFile = (path, data) => {
    // Write the data to the file
    fs.writeFile(path, JSON.stringify(data), (err) => {
        if (err) {
            return console.error('Error writing file:', err);
        }
        console.log('Data saved successfully!');
    });
};

var sleep = async (time) => {
    console.log(`Going to sleep ${time}ms`);
    return new Promise((resolve) => {
        setTimeout(() => resolve(), time);
    });
};

var randomTime = (min, max) => {
    return Math.floor(Math.random() * (max - min + 1)) + min;
};
