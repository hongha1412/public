const puppeteer = require('puppeteer');
const axios = require('axios');
const fs = require('fs');
const path = require('path');

// Path to save cookies
const DATA_PATH = path.join(__dirname, 'shb_sessiondata.json');
const BRANCHES_PATH = path.join(__dirname, 'shb.txt');
const FILTER_URL = `https://www.shb.com.vn/mangluoi/mang-luoi-hoat-dong/%page%?mangluoi_slug=mang-luoi-hoat-dong&key-text=&huyen=0&kieu%5B%5D=chinhanh&kieu%5B%5D=atm&oke=&tinh=`;

// Prepare data store
const data = { branches: [] };

(async () => {
    let sessionData;

    // Launch Puppeteer
    const browser = await puppeteer.launch({ headless: false });
    const page = await browser.newPage();

    // Navigate to the first URL
    await page.goto('https://www.shb.com.vn/mangluoi/mang-luoi-hoat-dong/');

    // Extract danhSachTinh
    const provinces = await page.evaluate(() => {
        const selectData = document.querySelectorAll('#tinh option');
        const parsedData = [];
        selectData.forEach((option, i) => {
            if (i <= 0) return;
            parsedData.push({
                name: option.innerText,
                value: option.value
            });
        });
        return parsedData;
    });

    let haveNextPage = false;
    // Crawling branches data from each province
    for (let i = 0; i < provinces.length; i += 1) {
        console.log('Getting branches for province: ' + provinces[i].name);
        await page.goto(FILTER_URL.replace('%page%', '') + provinces[i].value);

        do {
            const rs = await extractBranches(page);
            data.branches.push(...rs.map(b => {
                b.province = provinces[i].name;
                return b;
            }));
            // Check next page button
            haveNextPage = await page.$eval('.site-pagination > ul > li:last-child > a', () => true).catch(() => false);
            if (haveNextPage) {
                const nextPageUrl = await page.evaluate(() => {
                    return document.querySelector('.site-pagination > ul > li:last-child > a').href;
                });
                if (nextPageUrl) await page.goto(nextPageUrl);
                else haveNextPage = false;
            }
        } while (haveNextPage);
        // Sleep to make me looks like human
        await sleep(randomTime(2, 5) * 1000);
    }

    // Close the browser as it's no longer needed
    await browser.close();
    writeToFile(BRANCHES_PATH, data);
})();

var extractBranches = async (page) => {
    // Wait until the page is fully loaded
    await page.waitForSelector('.result-networks');

    return await page.evaluate(() => {
        const elements = document.querySelectorAll('.result-networks .row .items');
        const branches = [];
        for (let i = 0; i < elements.length; i++) {
            const info = elements[i].children[1].innerText.split('\n');
            branches.push({
                name: elements[i].children[0].innerText,
                address: info.shift(),
                additional: info,
            });
        }
        return branches;
    });
};

var writeToFile = (path, data) => {
    // Write the data to the file
    fs.writeFile(path, JSON.stringify(data), (err) => {
        if (err) {
            return console.error('Error writing file:', err);
        }
        console.log('Data saved successfully!');
    });
};

var sleep = async (time) => {
    console.log(`Going to sleep ${time}ms`);
    return new Promise((resolve) => {
        setTimeout(() => resolve(), time);
    });
};

var randomTime = (min, max) => {
    return Math.floor(Math.random() * (max - min + 1)) + min;
};

var dataMerge = (base, data) => {
    for (let key in data) {
        if (!base.hasOwnProperty(key)) {
            if (Array.isArray(data[key])) {
                base[key] = [];
            } else if (typeof data[key] === 'object' && data[key] !== null) {
                base[key] = {};
            } else {
                base[key] = data[key];
            }
        }

        if (Array.isArray(data[key])) {
            base[key] = base[key].concat(data[key]);
        } else if (typeof data[key] === 'object' && data[key] !== null) {
            dataMerge(base[key], data[key]);
        } else {
            base[key] = data[key];
        }
    }
};
