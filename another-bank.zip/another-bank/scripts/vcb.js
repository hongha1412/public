const puppeteer = require('puppeteer');
const axios = require('axios');
const fs = require('fs');
const path = require('path');

// Path to save cookies
const DATA_PATH = path.join(__dirname, 'vcb_sessiondata.json');
const BRANCHES_PATH = path.join(__dirname, 'vcb.txt');

// Prepare data store
const data = { branches: [] };

(async () => {
    // Request to get provinces
    try {
        const provinces = await axios.get(`https://www.vietcombank.com.vn/api/network/provincesresult?l=vi-VN`);
        data.provinces = provinces.data.provinces;
    } catch (error) {
        console.error('Error making API request provincesresult:', error);
    }
    
    // Get branches in provines
    for (let i = 0; i < data.provinces.length; i++) {
        const province = data.provinces[i];
        console.log(`Getting data for province: ${province.name}`);
        
        // Make api request to get branches in province
        const branches = await axios.post(`https://www.vietcombank.com.vn/api/network/filterdataresult`, {
            Longitude: '', Latitude: '', ProvinceCode: province.code, l: 'vi-VN', Chip: '{E57A2832-1BB1-4AAC-BCB6-5F2E30F723DC}'// Filter branch only (no ATM)
        });
        // Store into data
        data.branches.push(...branches.data.filterResults);
        // Flush current data to file
        writeToFile(BRANCHES_PATH, data);
        
        // Sleep between each request to make me looks like human
        sleep(randomTime(2, 5) * 1000);
    }
})();

var writeToFile = (path, data) => {
    // Write the data to the file
    fs.writeFile(path, JSON.stringify(data), (err) => {
        if (err) {
            return console.error('Error writing file:', err);
        }
        console.log('Data saved successfully!');
    });
};

var sleep = async (time) => {
    console.log(`Going to sleep ${time}ms`);
    return new Promise((resolve) => {
        setTimeout(() => resolve(), time);
    });
};

var randomTime = (min, max) => {
    return Math.floor(Math.random() * (max - min + 1)) + min;
};
