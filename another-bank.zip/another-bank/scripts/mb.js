const puppeteer = require('puppeteer');
const axios = require('axios');
const fs = require('fs');
const path = require('path');

// Path to save cookies
const DATA_PATH = path.join(__dirname, 'mb_sessiondata.json');

(async () => {
    let sessionData;

    // Check if cookies file exists
    try {
        const sessionDataFile = await fs.readFileSync(DATA_PATH, 'utf8');
        sessionData = JSON.parse(sessionDataFile);
        console.log('Session data loaded from file.');
    } catch (err) {
        console.log('Session data not found, accessing the first URL to get it.');

        // Launch Puppeteer
        const browser = await puppeteer.launch();
        const page = await browser.newPage();

        // Navigate to the first URL
        await page.goto('https://www.mbbank.com.vn/maps');

        // Wait until the page is fully loaded
        await page.waitForSelector('#map');
        await page.waitForSelector('input[name="__RequestVerificationToken"]');
        await page.waitForSelector('#sel');

        // Extract the numbers from the options of the select box
        const numbers = await page.evaluate(() => {
            const options = Array.from(document.querySelectorAll('#sel option'));
            return options.filter(option => option.value).map(option => option.value.match(/number:(\d+)/)[1]); // Extract the number
        });

        // Extract the value of the hidden input field
        const requestVerificationToken = await page.evaluate(() => {
            return document.querySelector('input[name="__RequestVerificationToken"]').value;
        });

        // Get all cookies from the first page
        const cookies = await page.cookies();

        // Save cookies and token to the local file system
        sessionData = {cookies, requestVerificationToken, pids: numbers};
        await fs.writeFile(DATA_PATH, JSON.stringify(sessionData, null, 2), (err) => err && console.error('Failed to save session data, skipping...'));
        console.log('Session data saved to file.');

        // Close the browser as it's no longer needed
        await browser.close();
    }

    // Format cookies for the API request
    const cookieHeader = sessionData.cookies.map(cookie => `${cookie.name}=${cookie.value}`).join('; ');
    // Prepare branches info
    const data = {};

    // Use the saved token and cookies to make the API request
    try {
        // Make API request with cookies
        for (let i = 0; i < sessionData.pids.length; i++) {
            console.log(`Getting data for province id: ${sessionData.pids[i]}`);
            const res = (await mbRequestBranch(sessionData.pids[i], cookieHeader, sessionData.requestVerificationToken));
            // Merge response into data for store in local file system
            dataMerge(data, res);
            // Flush data into file
            writeToFile('mb.txt', data);
            // IMPORTANT: Make me looks like human request
            await sleep(randomTime(2, 5) * 1000);
        }
    } catch (error) {
        console.error('Error making API request:', error);
    }
})();

var mbRequestBranch = async (provinceid, cookieHeader, requestVerificationToken) => {
    try {
        const branches = await axios.get(`https://www.mbbank.com.vn/api/getMaps/${provinceid}/0`, {
            headers: {
                'Cookie': cookieHeader,
                'Mb-Xsrf-Token-Formonline': requestVerificationToken
            }
        });
        const districts = await axios.get(`https://www.mbbank.com.vn/api/getDistrict/${provinceid}`, {
            headers: {
                'Cookie': cookieHeader,
                'Mb-Xsrf-Token-Formonline': requestVerificationToken
            }
        });

        // Extract data from API response
        return {branches: branches.data, districts: districts.data};
    } catch (error) {
        console.error('Error making API request:', error);
    }
};

var writeToFile = (path, data) => {
    // Write the data to the file
    fs.writeFile(path, JSON.stringify(data), (err) => {
        if (err) {
            return console.error('Error writing file:', err);
        }
        console.log('Data saved successfully!');
    });
};

var sleep = async (time) => {
    console.log(`Going to sleep ${time}ms`);
    return new Promise((resolve) => {
        setTimeout(() => resolve(), time);
    });
};

var randomTime = (min, max) => {
    return Math.floor(Math.random() * (max - min + 1)) + min;
};

var dataMerge = (base, data) => {
    for (let key in data) {
        if (!base.hasOwnProperty(key)) {
            if (Array.isArray(data[key])) {
                base[key] = [];
            } else if (typeof data[key] === 'object' && data[key] !== null) {
                base[key] = {};
            } else {
                base[key] = data[key];
            }
        }

        if (Array.isArray(data[key])) {
            base[key] = base[key].concat(data[key]);
        } else if (typeof data[key] === 'object' && data[key] !== null) {
            dataMerge(base[key], data[key]);
        } else {
            base[key] = data[key];
        }
    }
};
