const puppeteer = require('puppeteer');
const axios = require('axios');
const fs = require('fs');
const path = require('path');

// Path to save cookies
const DATA_PATH = path.join(__dirname, 'vietin_sessiondata.json');
const BRANCH_PATH = path.join(__dirname, 'vietin.txt');

(async () => {
    // Launch Puppeteer
    const browser = await puppeteer.launch({headless:false});
    const page = await browser.newPage();
    const data = {};
    
    // Navigate to the first URL
    await page.goto('https://www.vietinbank.vn/mang-luoi-chi-nhanh-atm');

    // Wait until the page is fully loaded
    await page.waitForSelector('#form');
    await page.waitForSelector('form dl');
    
    // Extract the numbers from the options of the select box
    const scripts = await page.evaluate(() => {
      const scriptInner = [];
      document.querySelectorAll('script').forEach(s => {
          scriptInner.push(s.innerHTML);
      });
      return scriptInner;
    });
    const provinces = parseProvince(scripts);
    
    // Extract branches data
    data.provinces = provinces;
    data.branches = [];
    for (let i = 0; i < provinces.networkProvince.length; i++) {
      const province = provinces.networkProvince[i];
      // Step 1: Open the Select2 dropdown
      await page.click('.react-select__value-container');

      // Step 2: Type to search or select the option (if searchable)
      await page.type('.react-select__input-container', province.province, { delay: 100 });
      
      // Wait for the dropdown options to appear
      await page.waitForSelector('#react-select-2-listbox');

      // Step 3: Select the option
      await page.click('[role="option"]');

      // Optional: Check the selected value
      const selectedValue = await page.evaluate(() => {
          return document.querySelectorAll('.react-select__single-value')[0].textContent;
      });
      
      // Wait for list branches updated
      await sleep(2000);
      await page.waitForSelector('form dl');

      console.log('Checking province:', selectedValue);
      const branches = await page.evaluate(() => {
        const ls = [];
        document.querySelectorAll('form dl').forEach(e => {
            const branch = {};
            const parts = e.innerText.split('\n');
            branch.type = parts.shift();
            branch.address = parts.pop();
            ls.push(branch);
        });
        return ls;
      });
      data.branches.push(...branches);
    }

    // Close the browser as it's no longer needed
    await browser.close();
    
    writeToFile(BRANCH_PATH, data);
})();

var parseProvince = (data) => {
    data = data.filter(s => s && s.indexOf('networkProvince') >= 0).pop();
    const provinces = '{' + data.substring(data.indexOf('networkProvince') - 2, data.length - 6);
    
    // Unescape the JSON string
    const unescapedJsonString = provinces.replace(/\\n/g, '\n').replace(/\\"/g, '\"').replace(/\\\\/g, '\\');
    
    // Parse the JSON string to an object
    try {
        return JSON.parse(unescapedJsonString);
    } catch (jsonParseError) {
        console.error('Error parsing JSON:', jsonParseError);
    }
    return null;
};

var writeToFile = (path, data) => {
    const str = typeof data === 'string' ? data : JSON.stringify(data);
    // Write the data to the file
    fs.writeFileSync(path, str, (err) => {
        if (err) {
            return console.error('Error writing file:', err);
        }
        console.log('Data saved successfully!');
    });
};

var sleep = async (time) => {
    console.log(`Going to sleep ${time}ms`);
    return new Promise((resolve) => {
        setTimeout(() => resolve(), time);
    });
};

var randomTime = (min, max) => {
    return Math.floor(Math.random() * (max - min + 1)) + min;
};
