const puppeteer = require('puppeteer');
const axios = require('axios');
const fs = require('fs');
const path = require('path');

// Path to save cookies
const DATA_PATH = path.join(__dirname, 'vpbank_sessiondata.json');
const BRANCHES_PATH = path.join(__dirname, 'vpbank.txt');

// Prepare data store
const data = { branches: [] };

(async () => {
    // Request to get branches and atms
    try {
        const branches = await axios.get(`https://www.vpbank.com.vn/api/branchandatm/searchbranchesandatms?keyword=&city=&district=`);
        data.branches.push(...branches.data.branches_and_atm);
    } catch (error) {
        console.error('Error making API request provincesresult:', error);
    }
    
    writeToFile(BRANCHES_PATH, data);
})();

var writeToFile = (path, data) => {
    // Write the data to the file
    fs.writeFile(path, JSON.stringify(data), (err) => {
        if (err) {
            return console.error('Error writing file:', err);
        }
        console.log('Data saved successfully!');
    });
};

var sleep = async (time) => {
    console.log(`Going to sleep ${time}ms`);
    return new Promise((resolve) => {
        setTimeout(() => resolve(), time);
    });
};

var randomTime = (min, max) => {
    return Math.floor(Math.random() * (max - min + 1)) + min;
};
