const puppeteer = require('puppeteer');
const axios = require('axios');
const fs = require('fs');
const path = require('path');
const https = require("https");

// Path to save cookies
const DATA_PATH = path.join(__dirname, 'tpbank_sessiondata.json');
const PROVINCES_PATH = path.join(__dirname, 'provinces.json');
const BRANCHES_PATH = path.join(__dirname, 'tpbank.txt');
const FILTER_URL = 'https://tpb.vn/wps/wcm/connect/tpbank_data/sa-others/sa-atm-branch/dgdm/%pid%?source=library&srv=cmpnt&cmpntid=';
// Prepare data store
const data = { branches: [] };

(async () => {
    // Extract danhSachTinh
    const provinces = JSON.parse(fs.readFileSync(PROVINCES_PATH, 'utf8'));

    // Launch Puppeteer
    const browser = await puppeteer.launch({ headless: false });
    const page = await browser.newPage();

    // Navigate to the first URL
    await page.goto('https://tpb.vn/tim-diem-giao-dich?iservice=4');

    // Wait until the page is fully loaded
    await page.waitForSelector('.dgd-content');

    // Extract pathCallLocation and cmpntid
    const cmpntid = await page.evaluate(() => {
        // Find the pathCallLocation string in the script
        const scripts = document.querySelectorAll('script');

        for (let i = 0; i < scripts.length; i++) {
            const scriptContent = scripts[i].innerText;
            const cmpntidMatch = scriptContent.match(/let\s+linkLocation\s*=\s*`[^`]*cmpntid=([a-f0-9\-]+)`/);

            if (cmpntidMatch && cmpntidMatch.length > 1) {
                return cmpntidMatch[1];
            }
        }

        return null;
    });

    const provinceKeys = Object.keys(provinces);
    for (let i = 0; i < provinceKeys.length; i++) {
        console.log('Requesting branches data for province: ' + provinces[provinceKeys[i]]);

        // Goto branches by province
        await page.goto(FILTER_URL.replace('%pid%', provinceKeys[i]) + cmpntid);

        // Wait until the page is fully loaded
        await page.waitForSelector('body');

        // Get page content
        try {
            data.branches.push(...JSON.parse(await page.evaluate(() => {
                return document.querySelector('body').innerText;
            })).map(b => {
                b.province = provinces[provinceKeys[i]];
                return b;
            }));
        } catch (e) {
            console.error('Cannot parse branches data', e);
        }

        // Sleep to make me looks like human
        await sleep(randomTime(2, 5) * 1000);
    }

    // Close the browser as it's no longer needed
    await browser.close();

    writeToFile(BRANCHES_PATH, data);
})();

var writeToFile = (path, data) => {
    // Write the data to the file
    fs.writeFile(path, JSON.stringify(data), (err) => {
        if (err) {
            return console.error('Error writing file:', err);
        }
        console.log('Data saved successfully!');
    });
};

var sleep = async (time) => {
    console.log(`Going to sleep ${time}ms`);
    return new Promise((resolve) => {
        setTimeout(() => resolve(), time);
    });
};

var randomTime = (min, max) => {
    return Math.floor(Math.random() * (max - min + 1)) + min;
};

var dataMerge = (base, data) => {
    for (let key in data) {
        if (!base.hasOwnProperty(key)) {
            if (Array.isArray(data[key])) {
                base[key] = [];
            } else if (typeof data[key] === 'object' && data[key] !== null) {
                base[key] = {};
            } else {
                base[key] = data[key];
            }
        }

        if (Array.isArray(data[key])) {
            base[key] = base[key].concat(data[key]);
        } else if (typeof data[key] === 'object' && data[key] !== null) {
            dataMerge(base[key], data[key]);
        } else {
            base[key] = data[key];
        }
    }
};
