const puppeteer = require('puppeteer');
const axios = require('axios');
const fs = require('fs');
const path = require('path');

// Path to save cookies
const DATA_PATH = path.join(__dirname, 'acb_sessiondata.json');
const BRANCHES_PATH = path.join(__dirname, 'acb.txt');

// Prepare data store
const data = { branches: [] };

(async () => {
    // Request to get branches and atms
    let currentPage = 1;
    let lastPage = 99;
    try {
        do {
            const branches = await axios.get(`https://acb.com.vn/api/front/v1/acb-branch?page=${currentPage}`);
            data.branches.push(...branches.data.data);
            currentPage = branches.data.meta.current_page + 1;
            lastPage = branches.data.meta.last_page;
            // Sleep to make me looks like human
            await sleep(randomTime(2, 5) * 1000);
        } while (currentPage <= lastPage);
    } catch (error) {
        console.error('Error making API request provincesresult:', error);
    }

    writeToFile(BRANCHES_PATH, data);
})();

var writeToFile = (path, data) => {
    // Write the data to the file
    fs.writeFile(path, JSON.stringify(data), (err) => {
        if (err) {
            return console.error('Error writing file:', err);
        }
        console.log('Data saved successfully!');
    });
};

var sleep = async (time) => {
    console.log(`Going to sleep ${time}ms`);
    return new Promise((resolve) => {
        setTimeout(() => resolve(), time);
    });
};

var randomTime = (min, max) => {
    return Math.floor(Math.random() * (max - min + 1)) + min;
};
